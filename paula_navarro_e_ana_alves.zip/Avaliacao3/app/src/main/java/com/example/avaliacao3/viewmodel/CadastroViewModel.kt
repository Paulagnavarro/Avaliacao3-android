package com.example.avaliacao3.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.avaliacao3.model.Jogo
import com.example.avaliacao3.model.ValidarJogo
import com.example.avaliacao3.repository.JogoRepository

class CadastroViewModel(application: Application): AndroidViewModel(application) {

    private var repository = JogoRepository(application.applicationContext)
    private var validacao = ValidarJogo()
    private var txtToast = MutableLiveData<String>()

    fun getTxtToast() : LiveData<String> {
        return txtToast
    }

    fun salvar(nomeJogador: String, level: String, gear: String, modifier: String) : Boolean {

        if (validacao.camposEmBranco(nomeJogador, level, gear, modifier)){
            txtToast.value = "Preencha todos os campos"
            return false
        }

        var jogo = Jogo(
            0,
            nomeJogador,
            level.toInt(),
            gear.toInt(),
            modifier.toInt()
        )

        if(validacao.valorLevelInvalido(jogo.level)){
            txtToast.value = "level deve estar entre 0 e 100"
            return false
        }

        if(validacao.valorGearInvalido(jogo.gear)){
            txtToast.value = "gear deve estar entre 0 e 100"
            return false
        }

        if (!repository.salvar(jogo)){
            txtToast.value = "Erro ao salvar..."
            return false
        }

        txtToast.value = "Jogo salvo!"
        return true
    }

}