package com.example.avaliacao3.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.avaliacao3.model.Jogo
import com.example.avaliacao3.model.ValidarJogo
import com.example.avaliacao3.repository.JogoRepository

class JogoViewModel(application: Application): AndroidViewModel(application) {

    private var repository = JogoRepository(application.applicationContext)
    private var validacao = ValidarJogo()
    private var jogoFromDB = MutableLiveData<Jogo>()
    private var txtToast = MutableLiveData<String>()

    fun getJogoFromDB() : LiveData<Jogo> {
        return jogoFromDB
    }

    fun getTxtToast(): LiveData<String> {
        return txtToast
    }

    fun findJogo(id: Int){
        jogoFromDB.value = repository.getJogo(id)
    }


    fun validarAntesDeAtualizar(nomeJogador: String, level: String, gear: String, modifier: String) : Boolean {
        if (validacao.camposEmBranco(nomeJogador , level, gear, modifier)){
            txtToast.value = "Preencha todos os campos!"
            return false
        }

        if (validacao.valorLevelInvalido(level.toInt()) || validacao.valorGearInvalido(gear.toInt())){
            txtToast.value = "level e gear devem estar entre 0 e 100"
            return false
        }

        return true
    }

    fun atualizar(jogo: Jogo){
        repository.atualizar(jogo)
        txtToast.value = "Jogo atualizado!"
    }


}