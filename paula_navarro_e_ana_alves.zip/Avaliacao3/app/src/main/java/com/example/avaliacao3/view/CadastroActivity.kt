package com.example.avaliacao3.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.avaliacao3.R
import com.example.avaliacao3.databinding.ActivityCadastroBinding
import com.example.avaliacao3.viewmodel.CadastroViewModel

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var viewModel: CadastroViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(CadastroViewModel::class.java)

        setObservers()

        binding.btnSalvar.setOnClickListener {

            val nomeJogador = binding.edtNomeJogador.text.toString()
            val level = binding.edtLevel.text.toString()
            val gear = binding.edtGear.text.toString()
            val modifier = binding.edtModifier.text.toString()

            if(viewModel.salvar(nomeJogador, level, gear, modifier)){
                finish()
            }
        }
    }

    fun setObservers(){
        viewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
    }
}