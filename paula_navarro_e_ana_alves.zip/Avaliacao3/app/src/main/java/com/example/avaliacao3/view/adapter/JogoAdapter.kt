package com.example.avaliacao3.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.avaliacao3.R
import com.example.avaliacao3.model.Jogo
import com.example.avaliacao3.view.viewholder.JogoViewHolder

class JogoAdapter(var context: Context): RecyclerView.Adapter<JogoViewHolder>() {

    lateinit var listaAdapter : List<Jogo>
    var onItemLongClick : ((Int) -> Unit)? = null
    var onItemClick : ((Int) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JogoViewHolder {
        val layout = LayoutInflater.from(context)
            .inflate(R.layout.jogo_layout, parent, false)
        return JogoViewHolder(layout)
    }

    override fun onBindViewHolder(holder: JogoViewHolder, position: Int) {
        val jogo = listaAdapter[position]
        val txtHolder = "${jogo.nomeJogador} - Level:${jogo.level} / Gear:${jogo.gear} / Modifier:${jogo.modifier}"
        holder.txtDadosJogo.text = txtHolder

        holder.itemView.setOnLongClickListener{
            onItemLongClick?.invoke(position)
            true
        }

        holder.itemView.setOnClickListener{
            onItemClick?.invoke(position)
        }

    }

    override fun getItemCount(): Int {
        return listaAdapter.size
    }

    fun updateAdapter(list: List<Jogo>){
        listaAdapter = list
        notifyDataSetChanged()
    }
}