package com.example.avaliacao3.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.avaliacao3.R
import com.example.avaliacao3.databinding.ActivityJogoBinding
import com.example.avaliacao3.model.Jogo
import com.example.avaliacao3.model.ValidarJogo
import com.example.avaliacao3.viewmodel.JogoViewModel

class JogoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityJogoBinding
    private lateinit var viewModel : JogoViewModel
    private lateinit var jogo: Jogo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJogoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(JogoViewModel::class.java)

        setObservers()

        val id = intent.getIntExtra("id", 0)

        if(id == 0){
            finish()
        } else {
            viewModel.findJogo(id)
        }

        binding.btnConfirmar.setOnClickListener{
            val level  = binding.edtVerLevel.text.toString()
            val gear = binding.edtVerGear.text.toString()
            val modifier = binding.edtVerModifier.text.toString()

            if (viewModel.validarAntesDeAtualizar(jogo.nomeJogador, level, gear, modifier)){
                jogo.level = level.toInt()
                jogo.gear = gear.toInt()
                jogo.modifier = modifier.toInt()
                viewModel.atualizar(jogo)
                finish()
            }
        }
    }
    fun setObservers(){
        viewModel.getJogoFromDB().observe(this){
            jogo = it
            binding.txtVerJogador.text = jogo.nomeJogador
            binding.edtVerLevel.setText(jogo.level.toString())
            binding.edtVerGear.setText(jogo.gear.toString())
            binding.edtVerModifier.setText(jogo.modifier.toString())
        }
        viewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
    }
}
