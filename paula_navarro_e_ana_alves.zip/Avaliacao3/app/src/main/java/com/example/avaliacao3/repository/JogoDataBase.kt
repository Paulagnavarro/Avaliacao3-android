package com.example.avaliacao3.repository

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.avaliacao3.model.Jogo

@Database(entities = [Jogo::class], version = 1)
abstract class JogoDataBase : RoomDatabase(){

    abstract fun getDAO() : JogoDAO

    companion object{

        private lateinit var INSTANCE: JogoDataBase

        fun getInstace(context: Context): JogoDataBase {

            if(!::INSTANCE.isInitialized){
                INSTANCE = Room.databaseBuilder(context, JogoDataBase::class.java, "jogos_db")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}