package com.example.avaliacao3.repository

import androidx.room.*
import com.example.avaliacao3.model.Jogo

@Dao
interface JogoDAO {

    @Insert
    fun salvar(jogo: Jogo) : Long

    @Update
    fun atualizar(jogo: Jogo)

    @Delete
    fun deletar (jogo: Jogo)

    @Query("SELECT * FROM jogos WHERE id = :id")
    fun getJogo(id: Int): Jogo

    @Query("SELECT * FROM jogos")
    fun getAll() : List<Jogo>


}