package com.example.avaliacao3.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jogos")
data class Jogo (
    @ColumnInfo @PrimaryKey(autoGenerate = true) var id: Int,
    @ColumnInfo(name = "nome_jogador") var nomeJogador: String,
    @ColumnInfo var level: Int,
    @ColumnInfo var gear: Int,
    @ColumnInfo var modifier: Int
)