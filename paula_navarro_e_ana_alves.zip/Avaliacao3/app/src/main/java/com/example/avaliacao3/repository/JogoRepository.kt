package com.example.avaliacao3.repository

import android.content.Context
import com.example.avaliacao3.model.Jogo

class JogoRepository(context: Context) {

    val dao = JogoDataBase.getInstace(context).getDAO()

    fun salvar(jogo: Jogo) : Boolean{
        return dao.salvar(jogo) > 0
    }

    fun atualizar(jogo: Jogo) {
        dao.atualizar(jogo)
    }

    fun deletar(jogo: Jogo){
        dao.deletar(jogo)
    }

    fun getJogo(id: Int): Jogo {
        return dao.getJogo(id)
    }

    fun getAll() : List<Jogo> {
        return dao.getAll()
    }

}