package com.example.avaliacao3.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.avaliacao3.model.Jogo
import com.example.avaliacao3.repository.JogoRepository

class MainViewModel(application: Application): AndroidViewModel(application) {

    private var repository = JogoRepository(application.applicationContext)
    private var listViewModel = MutableLiveData<List<Jogo>>()
    private var txtToast = MutableLiveData<String>()

    fun getListViewModel() : LiveData<List<Jogo>> {
        return listViewModel
    }

    fun getTxtToast() : LiveData<String> {
        return txtToast
    }

    fun getListFromDB() {
        listViewModel.value = repository.getAll()
    }

    fun deletar(jogo: Jogo){
        repository.deletar(jogo)
        txtToast.value = "jogo excluído!"
    }

}