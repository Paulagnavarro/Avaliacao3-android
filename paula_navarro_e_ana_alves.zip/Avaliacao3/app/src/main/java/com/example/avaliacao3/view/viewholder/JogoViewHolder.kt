package com.example.avaliacao3.view.viewholder

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.avaliacao3.R

class JogoViewHolder(layout: View): RecyclerView.ViewHolder(layout) {

    var txtDadosJogo = layout.findViewById<TextView>(R.id.txtDadosJogo)

}