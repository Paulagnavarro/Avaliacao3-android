package com.example.avaliacao3.model

class ValidarJogo {

    fun camposEmBranco(nomeJogador : String, level: String, gear: String, modifier: String) : Boolean{
        return nomeJogador.isEmpty() || level.isEmpty() || gear.isEmpty() || modifier.isEmpty()
    }

    fun valorLevelInvalido(level: Int) : Boolean {
        return level < 0 || level > 100
    }

    fun valorGearInvalido(gear: Int) : Boolean {
        return gear < 0 || gear > 100
    }

    fun valorForca(level: Int, gear: Int, modifier: Int) : Int {
        val resultado = level + gear + modifier
        return resultado
    }

}